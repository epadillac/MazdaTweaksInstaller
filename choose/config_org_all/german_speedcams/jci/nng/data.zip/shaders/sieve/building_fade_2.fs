precision mediump float;

uniform vec3 Ucolor;

void main() 
{
	gl_FragColor.rgb = Ucolor;
	gl_FragColor.a = 1.;	

	if( floor(mod(gl_FragCoord.x, 2.)) < 0.9 &&
	    floor(mod(gl_FragCoord.y+1., 2.)) < 0.9 )
		gl_FragColor.a = 0.;

}
