precision mediump float;
varying vec2 v_txCoor;
uniform sampler2D texture;
uniform vec4 Ucolor;
void main()
{
	vec4 c = texture2D( texture, v_txCoor );
	gl_FragColor = vec4(c.rgb, c.a*Ucolor.a);
}
