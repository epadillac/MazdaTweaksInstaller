precision mediump float;
uniform vec2 uBuildingParams;
uniform sampler2D texture;
uniform sampler2D texture2;

varying vec2 v_txCoor;
varying vec2 v_txCoor2;

void main()
{
	if( floor(mod(gl_FragCoord.x+gl_FragCoord.y+1., 2.)) < 0.9 )
		discard;

	float warp = texture2D( texture2, v_txCoor2.xy ).a;	
	if( warp > uBuildingParams.y + 0.1 )
		discard;

	gl_FragColor.rgb = texture2D( texture, v_txCoor ).rgb;
	gl_FragColor.a = 1.;
}
