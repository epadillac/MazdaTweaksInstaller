precision mediump float;
//uniform vec4 Ucolor;
uniform sampler2D texture;
uniform vec2 uBuildingParams;

varying vec2 v_txCoor;
varying vec4 v_Color;

void main()
{
	vec4 col = texture2D( texture, v_txCoor ) * v_Color;
	if( col.a < 0.5 )
		discard;

	col.a = col.a * uBuildingParams.x;
	gl_FragColor = col;
}
