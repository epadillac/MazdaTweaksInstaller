precision mediump float;

uniform vec3 Ucolor;

void main() 
{
	gl_FragColor.rgb = Ucolor;
	gl_FragColor.a = 0.5;	
}
