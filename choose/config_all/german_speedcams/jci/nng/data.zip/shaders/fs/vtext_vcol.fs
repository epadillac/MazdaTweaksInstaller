precision mediump float;

varying vec4 v_color;
varying vec2 v_txCoor;
uniform sampler2D texture;

void main()
{
	gl_FragColor = texture2D( texture, v_txCoor ) * v_color;
}
