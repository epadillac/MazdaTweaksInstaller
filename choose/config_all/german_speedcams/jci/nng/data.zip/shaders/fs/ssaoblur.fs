precision mediump float;
uniform sampler2D texture;

varying vec2 v_txCoor;
varying vec4 v_txCoor1;
varying vec4 v_txCoor2;

void main()
{
 	float value  = texture2D( texture, v_txCoor1.xy ).y * 0.065421;
 	      value += texture2D( texture, v_txCoor1.zw ).y * 0.242991;
 	      value += texture2D( texture, v_txCoor     ).y * 0.383177;
 	      value += texture2D( texture, v_txCoor2.xy ).y * 0.242991;
 	      value += texture2D( texture, v_txCoor2.zw ).y * 0.065421;

 	gl_FragColor.x = 0.;
 	gl_FragColor.y = value;
 	gl_FragColor.z = 0.;
 	gl_FragColor.w = 1.;
}
