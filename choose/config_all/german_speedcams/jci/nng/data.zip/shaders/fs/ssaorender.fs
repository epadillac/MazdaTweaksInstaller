precision mediump float;

varying vec2 v_txCoor;

uniform sampler2D texture;

void main()
{
 	float occ = texture2D( texture, v_txCoor ).y;

 	gl_FragColor.x = 0.;
 	gl_FragColor.y = 0.;
 	gl_FragColor.z = 0.;
 	gl_FragColor.w = occ;
}
